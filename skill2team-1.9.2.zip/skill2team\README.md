# Skill2Team

[![Version](https://img.shields.io/badge/version-1.9.2-blue.svg)](#release-notes)
[![Runtime](https://img.shields.io/badge/runtime-OpenAI%20Codex-111827.svg)](#model-invocation-policy)
[![License](https://img.shields.io/badge/license-MIT--0-green.svg)](#license)

Skill2Team converts skills, prompts, SOPs, workflow documents, tools, and existing agent packages into compact, auditable **profile-based multi-agent team designs**. It can also package those designs into a concrete **OpenAI Codex target-team package**.

Version `1.9.2` focuses on framework-neutral agent architecture, design/package conformance, preserved human-in-the-loop workflow steps, and Codex-ready team delivery.

## Highlights

- Converts source skills or workflow material into profile-based agent teams.
- Separates the **Agent Architecture Map** from the **Workflow Orchestration Map**.
- Uses a framework-neutral agent relationship graph rather than a LangGraph-specific default.
- Preserves source user-input nodes and human intervention points by default.
- Adds an entry-agent startup welcome page adapted from the source skill.
- Produces both design output and package output when `Delivery: package` is selected.
- Includes `design-output.zip` inside generated target-team packages.
- Keeps package-end guidance Codex-only: register, smoke test, and start the converted target team in Codex.
- Supports both `direct-skill` and `meta-team-first` paths with the same target-team artifact contract.
- Requires independent audit for generated meta-team and target-team package quality.

## Package

The current clean package is:

```text
skill2team-1.9.2-clawhub-skill-creator-clean.zip
```

It contains the `skill2team/` skill folder with:

```text
SKILL.md
agents/
assets/
data/
examples/
prompts/
references/
scripts/
LICENSE
README.md
```

## Install

Unzip the package into your Codex skills directory:

```bash
unzip skill2team-1.9.2-clawhub-skill-creator-clean.zip -d ~/.codex/skills
```

On Windows PowerShell:

```powershell
Expand-Archive -LiteralPath .\skill2team-1.9.2-clawhub-skill-creator-clean.zip -DestinationPath $env:USERPROFILE\.codex\skills
```

After extraction, Codex should discover the skill as `skill2team`.

## Quick Start

Start the skill:

```text
Start Skill2Team.
```

Generate a Codex package from a source skill:

```text
Start Skill2Team.
Route: source-to-team
Delivery: package
Execution path: meta-team-first
Target runtime: codex
Model invocation policy: use OpenAI Codex; do not call direct model APIs.
Source material: [paper-framework-figure-studio-pro-v3.2.15c-skill.zip](paper-framework-figure-studio-pro-v3.2.15c-skill.zip)
Human-interaction mode: preserve source human-interaction steps by default.
```

Generate design only:

```text
Start Skill2Team.
Route: source-to-team
Delivery: design
Execution path: direct-skill
Target runtime: codex
Source material: <SOURCE_SKILL_ZIP>
```

## Routes

| Route | Purpose |
| --- | --- |
| `source-to-team` | Convert or restructure an existing skill, agent package, SOP, prompt set, or workflow into a target team. |
| `brief-to-team` | Turn a natural-language brief into a first team design. |
| `guided-to-team` | Ask focused setup questions before design/package when the source is unclear or high risk. |

## Delivery Modes

Skill2Team exposes two user-facing delivery modes:

| Delivery | Output |
| --- | --- |
| `design` | Inventory, diagnosis, architecture map, workflow map, control-flow/resume contract, profile roster, quality gates, and design-continuation prompts. |
| `package` | Everything in `design`, plus a concrete Codex target-team package with generated agents, profiles, manifests, usage guide, `design-output.zip`, startup welcome page, conformance contracts, and Codex package-use prompts. |

`validate` is not a user-facing delivery mode. Validation is embedded in design quality gates and package release gates.

## Model Invocation Policy

Skill2Team defaults model execution to **OpenAI Codex** for:

- running Skill2Team itself;
- running the fixed `s2t-meta-*` meta-team agents;
- running generated target-team agents.

Direct API model service should only be used when explicitly requested, and must be labeled as API-service follow-up or API-run role simulation.

## Human-in-the-loop Preservation

At the start of source conversion, Skill2Team should ask whether to:

| Mode | Meaning |
| --- | --- |
| `preserve_source_human_interaction_steps` | Preserve source user-input nodes, approvals, waits, checkpoints, and terminal boundaries. This is the default. |
| `selective_human_interaction_retention` | Preserve only selected source human-interaction points and convert others with explicit rationale. |
| `fully_automated_with_audit` | Auto-advance where possible, but only after explicit user selection and audit recording. |

Generated target teams must not silently run straight through source workflows that originally required user choices.

## Target-team Package Contract

A generated Codex package should include:

- generated entry and specialist agent profiles;
- `.codex/agents/*.toml` files;
- package and registry manifests;
- `design-output.zip` and `design-output-manifest.json`;
- `entry-agent-startup-welcome.json`;
- `docs/entry-agent-startup-welcome.md`;
- `local-resource-allocation.map.json`;
- `source-resource-manifest.json`;
- workflow preservation and package release gates;
- `design-package-conformance.contract.json`;
- `runtime-instruction-conformance.json`;
- `meta-team-audit.contract.json`;
- Codex-only package-end prompts for registration, smoke tests, and target-team use.

## Architecture Model

Skill2Team uses a framework-neutral agent architecture relationship graph:

```mermaid
flowchart LR
    U["User / Source Task"] --> E["Entry Agent"]
    E --> M["Source Mapper"]
    E --> A["Architecture Designer"]
    E --> W["Workflow Orchestrator"]
    E --> R["Runtime Adapter"]
    A --> Q["Independent Reviewer"]
    W --> Q
    R --> Q
    Q --> E
```

Agent profiles are nodes. Delegation, handoffs, routing, state/artifact flow, guardrails, user-input nodes, fan-out/fan-in, checkpoints, review gates, and terminal boundaries are typed edges.

## Local QA

After extracting the package, run:

```bash
python scripts/validate_package.py .
```

Generate a sample package:

```bash
python scripts/generate_deployment_package.py examples/sample_team_plan.json /tmp/s2t_deploy --target codex --delivery package
```

On Windows PowerShell:

```powershell
python .\scripts\validate_package.py .
python .\scripts\generate_deployment_package.py .\examples\sample_team_plan.json F:\tmp\s2t_deploy --target codex --delivery package
```

## Release Notes

### 1.9.2

- Replaced LangGraph-style default architecture wording with framework-neutral agent architecture relationship graphs.
- Split design-continuation prompts from package-end prompts.
- Restricted package-end prompts to Codex package registration, smoke testing, and use.
- Added required `design-output.zip` generation for package delivery.
- Added entry-agent startup welcome artifacts.
- Added default preservation of source human-interaction steps and required user-input nodes.
- Required direct-skill and meta-team-first packages to follow the same artifact contract.
- Added independent audit expectations for generated meta-team and package quality.

## License

Skill2Team is distributed under MIT-0. See `LICENSE` and `license.txt` in the package.
